import React, {Component} from 'react';
import {Text, View, Image, TextInput, Alert,Button,StyleSheet, ScrollView,FlatList} from 'react-native';
import data1 from './data/data1';
class Hello extends Component {
    render() {
        return (
            <Text>Hello (this.props.name)</Text>
        );
    }
}
//get Data item
class GetDataItem extends Component {
    render() {
        return (
            <View>
                <Text>{this.props.item.id}</Text>
                <Text>{this.props.item.title}</Text>
                <Text>{this.props.item.descreption}</Text>
                <Text>-------------</Text>
            </View>
        )
    }
}
export default class Helloworld extends Component {
    constructor(props) {
        super(props);
        this.state={
            TextInputName: '',
            TextInputEmail: '',
            TextInputPhoneNumber: ''
        }
    }
    CheckInputValue = () => {
        const { TextInputName }  = this.state ;
        const { TextInputEmail }  = this.state ;
        const { TextInputPhoneNumber }  = this.state ;
        if(TextInputName == '' || TextInputEmail == '' || TextInputPhoneNumber == '')
        {
            Alert.alert('Nhap du thong tin');
        }
        else {
            Alert.alert(typedText);
        }
    }

    render () {
        let pic = {
            uri:'./img/DOIlogo.png'
          };
          return (
              <ScrollView>
            <View style={styles.MainContainer}>
                  <Image
                source={{
                    uri: '/img/DOIlogo.png',
                    cache: 'only-if-cached',
                }}
                style={{width: 400, height: 200}}
                />
                
                <Text>Ten</Text>
                <TextInput style={{ height:40,width:300,margin:10,borderWidth:1,borderColor:'gray'}}
                placeholder='HO va ten'
                onChangeText={TextInputName => {this.setState({TextInputName})}}
                style={styles.TextInput}                 
                />
                <Text>{this.props.TextInputName}</Text>
                <Text>Email</Text>
                <TextInput style={{ height:40,width:300,margin:10,borderWidth:1,borderColor:'gray'}}
                keyboardType='email-address'
                placeholder='Email'
                onChangeText={TextInputEmail => {this.setState({TextInputEmail})} }
                style={styles.TextInput}               
                />
                <Text>{this.props.TextInputEmail}</Text>
                <Text>SDT</Text>
                <TextInput style={{ height:40,width:300,margin:10,borderWidth:1,borderColor:'gray'}}
                keyboardType='email-address'
                placeholder='so dien thoai'
                onChangeText={TextInputPhoneNumber => {this.setState({TextInputPhoneNumber})}
                }    
                style={styles.TextInput}              
                />
                <Text>{this.props.TextInputPhoneNumber}</Text>
                <Button onPress={this.CheckInputValue} title="Bam" style={{marginBottom:20}}></Button>
                <Text>Get Data</Text>
                <FlatList
                    data = {data1}
                    renderItem={({item,index}) => {
                        //console.log('Item = ${id}, index=${index}');
                        return(
                            <GetDataItem item={item} index={index}></GetDataItem>
                        );
                    }}>
                </FlatList>
                <Image
                source={{
                    uri: 'https://mytourcdn.com/upload_images/Image/Location/22_11_2016/12/du-lich-ha-noi-cho-long-diu-lai-mytour-3.jpg',
                    cache: 'only-if-cached',
                }}
                style={{width: 400, height: 200, marginTop:20}}
                />
                <Image
                source={{
                    uri: 'https://mytourcdn.com/upload_images/Image/Location/22_11_2016/12/du-lich-ha-noi-cho-long-diu-lai-mytour-1.jpg',
                    cache: 'only-if-cached',
                }}
                style={{width: 400, height: 200}}
                />
            </View>
            </ScrollView>
        );        
    }
}
const styles = StyleSheet.create(
    {
        MainContainer: {
            justifyContent: 'center',
            flex:1,
            margin:10
        },
        TextInput: {
            textAlign:'center',
            marginBottom:10,
            height:40,
            borderWidth:1,
            borderColor:'red'
        },
    }
)