var data1 = [
    {
        "id": "1",
        "title": "Mot",
        "descreption": "des1"

    },
    {
        "id": "2",
        "title": "Hai",
        "descreption": "des2"

    },
    {
        "id": "3",
        "title": "Ba",
        "descreption": "des3"

    },
    {
        "id": "4",
        "title": "Bon",
        "descreption": "des4"

    },
    {
        "id": "5",
        "title": "Nam",
        "descreption": "des5"

    }

];
module.exports = data1;